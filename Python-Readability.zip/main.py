import cs50

# Function to count number of letters
def letter_counter(text, length):
    letter_count = 0
    for i in range(length):
        if text[i].isalpha() == True:
            letter_count = letter_count + 1
    #print("Letters: " + str(letter_count))
    return letter_count

# Function to count number of sentences
def sentence_counter(text, length):
    sentence_count = 0
    for i in range(length):
        if text[i] == "." or text[i] == "!" or text[i] == "?":
            sentence_count = sentence_count + 1
    #print("Sentences: " + str(sentence_count))
    return sentence_count

# Function to count number of words
def word_counter(text, length):
    word_count = 0
    for i in range(length):
        if text[i].isspace() == True:
            word_count = word_count + 1
    #print("Words: " + str(word_count+1) )
    return word_count + 1

# Function to calculate L, S and the CL index
def calculation(letters, sentences, words):
    # Calculating L
    L = float(letters) / float(words) * 100

    # Calculating S
    S = float(sentences) / float(words) * 100

    # CL Index
    index = (0.0588 * L) - (0.296 * S) - 15.8

    #print("Calculation: " + str(index))
    return index

# Function to determine return grade level based on number
def grade_level(calc_grade):
    # Rounding the grade
    rounded_grade = round(calc_grade)
    # If else statements
    if rounded_grade >= 16:
        print("Grade 16+")
    elif rounded_grade < 1:
        print("Before Grade 1")
    elif rounded_grade >= 1 and rounded_grade < 16:
        print("Grade " + str(rounded_grade))

# Main function
text = cs50.get_string("Text: ")
length = len(text)

letters = letter_counter(text, length)
sentences = sentence_counter(text, length)
words = word_counter(text, length)
calc_grade = calculation(letters, sentences, words)
grade_level(calc_grade)